# swagger_client.HorizontalApi

All URIs are relative to *https://localhost/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**horizontal_create_resource**](HorizontalApi.md#horizontal_create_resource) | **POST** /intersite-horizontal | Horizontal request to create an inter-site Resource POST
[**horizontal_delete_resource**](HorizontalApi.md#horizontal_delete_resource) | **DELETE** /intersite-horizontal/{global_id} | Deletes an inter-site Resource DELETE
[**horizontal_read_parameters**](HorizontalApi.md#horizontal_read_parameters) | **GET** /intersite-horizontal/{global_id} | Read the local cidr of an inter-site Resource
[**horizontal_update_resource**](HorizontalApi.md#horizontal_update_resource) | **PUT** /intersite-horizontal/{global_id} | Update an already deployed resource
[**horizontal_verification**](HorizontalApi.md#horizontal_verification) | **GET** /intersite-horizontal | Horizontal request to verify remote items


# **horizontal_create_resource**
> object horizontal_create_resource(resource)

Horizontal request to create an inter-site Resource POST

Horizontal request to create an inter-site Resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HorizontalApi()
resource = swagger_client.Resource2() # Resource2 | data for inter-site creation

try:
    # Horizontal request to create an inter-site Resource POST
    api_response = api_instance.horizontal_create_resource(resource)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HorizontalApi->horizontal_create_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource** | [**Resource2**](Resource2.md)| data for inter-site creation | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **horizontal_delete_resource**
> horizontal_delete_resource(global_id)

Deletes an inter-site Resource DELETE

Deletes an inter-site resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HorizontalApi()
global_id = 'global_id_example' # str | Id of the resource to delete

try:
    # Deletes an inter-site Resource DELETE
    api_instance.horizontal_delete_resource(global_id)
except ApiException as e:
    print("Exception when calling HorizontalApi->horizontal_delete_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **global_id** | **str**| Id of the resource to delete | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **horizontal_read_parameters**
> object horizontal_read_parameters(global_id)

Read the local cidr of an inter-site Resource

Read one inter-site resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HorizontalApi()
global_id = 'global_id_example' # str | 

try:
    # Read the local cidr of an inter-site Resource
    api_response = api_instance.horizontal_read_parameters(global_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HorizontalApi->horizontal_read_parameters: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **global_id** | **str**|  | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **horizontal_update_resource**
> object horizontal_update_resource(global_id, resource=resource)

Update an already deployed resource

Update an already deployed resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HorizontalApi()
global_id = 'global_id_example' # str | Global ID of the resource to update
resource = swagger_client.Resource3() # Resource3 |  (optional)

try:
    # Update an already deployed resource
    api_response = api_instance.horizontal_update_resource(global_id, resource=resource)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HorizontalApi->horizontal_update_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **global_id** | **str**| Global ID of the resource to update | 
 **resource** | [**Resource3**](Resource3.md)|  | [optional] 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **horizontal_verification**
> object horizontal_verification(subresource_cidr, resource_type, global_id, verification_type)

Horizontal request to verify remote items

Horizontal request to verify an inter-site Resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HorizontalApi()
subresource_cidr = 'subresource_cidr_example' # str | data for inter-site verification
resource_type = 'resource_type_example' # str | Resource type to valite the cidr
global_id = 'global_id_example' # str | Resource global ID
verification_type = 'verification_type_example' # str | Type of verification definer

try:
    # Horizontal request to verify remote items
    api_response = api_instance.horizontal_verification(subresource_cidr, resource_type, global_id, verification_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HorizontalApi->horizontal_verification: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subresource_cidr** | **str**| data for inter-site verification | 
 **resource_type** | **str**| Resource type to valite the cidr | 
 **global_id** | **str**| Resource global ID | 
 **verification_type** | **str**| Type of verification definer | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

