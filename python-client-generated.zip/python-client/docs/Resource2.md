# Resource2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_global** | **str** | First created ID of the resource | [optional] 
**type** | **str** | Type of inter-site resource | [optional] 
**name** | **str** | Name of the inter-site resource | [optional] 
**params** | **list[str]** | Additional params for the inter-site resource | [optional] 
**subresources** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


