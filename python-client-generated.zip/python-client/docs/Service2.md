# Service2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_global** | **str** | First created ID of the service | [optional] 
**type** | **str** | Type of inter-site service | [optional] 
**name** | **str** | Name of the inter-site service | [optional] 
**params** | **list[str]** | Additional params for the inter-site service | [optional] 
**resources** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


