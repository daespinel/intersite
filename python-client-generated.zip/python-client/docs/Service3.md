# Service3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resources** | **list[str]** |  | [optional] 
**params** | **list[str]** |  | [optional] 
**post_create_refresh** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


