# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_id** | **str** | ID of the inter-site resource | [optional] 
**resource_type** | **str** | Inter-site resource type (L2 or L3) | [optional] 
**resource_name** | **str** | Name of the inter-site resource | [optional] 
**resource_params** | **str** | Additional params for the inter-site resource | [optional] 
**resource_subresources** | [**list[IntersiteverticalResourceSubresources]**](IntersiteverticalResourceSubresources.md) | SubResourcess to federate | [optional] 
**resource_interconnections** | [**list[IntersiteverticalResourceInterconnections]**](IntersiteverticalResourceInterconnections.md) | Locally created interconnections | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


