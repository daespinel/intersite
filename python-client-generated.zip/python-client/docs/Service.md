# Service

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | Type of inter-site service | [optional] 
**name** | **str** | Name of the inter-site service | [optional] 
**resources** | **list[str]** | Resources belonging to the user | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


