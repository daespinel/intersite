# swagger_client.ResourcesApi

All URIs are relative to *https://localhost/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**vertical_create_resource**](ResourcesApi.md#vertical_create_resource) | **POST** /intersite-vertical | Creates an inter-site Resource POST
[**vertical_delete_resource**](ResourcesApi.md#vertical_delete_resource) | **DELETE** /intersite-vertical/{global_id} | Deletes an inter-site Resource DELETE
[**vertical_read_all_resource**](ResourcesApi.md#vertical_read_all_resource) | **GET** /intersite-vertical | the inter-site Resource mapping structure GET
[**vertical_read_one_resource**](ResourcesApi.md#vertical_read_one_resource) | **GET** /intersite-vertical/{global_id} | Read one inter-site Resource GET
[**vertical_update_resource**](ResourcesApi.md#vertical_update_resource) | **PUT** /intersite-vertical/{global_id} | Update an already deployed resource


# **vertical_create_resource**
> object vertical_create_resource(resource)

Creates an inter-site Resource POST

Create an inter-site resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ResourcesApi()
resource = swagger_client.Resource() # Resource | data for inter-resource creation

try:
    # Creates an inter-site Resource POST
    api_response = api_instance.vertical_create_resource(resource)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ResourcesApi->vertical_create_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resource** | [**Resource**](Resource.md)| data for inter-resource creation | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **vertical_delete_resource**
> vertical_delete_resource(global_id)

Deletes an inter-site Resource DELETE

Deletes an inter-site resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ResourcesApi()
global_id = 'global_id_example' # str | Id of the resource to delete

try:
    # Deletes an inter-site Resource DELETE
    api_instance.vertical_delete_resource(global_id)
except ApiException as e:
    print("Exception when calling ResourcesApi->vertical_delete_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **global_id** | **str**| Id of the resource to delete | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **vertical_read_all_resource**
> list[InlineResponse200] vertical_read_all_resource()

the inter-site Resource mapping structure GET

Read the list of inter-site resources

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ResourcesApi()

try:
    # the inter-site Resource mapping structure GET
    api_response = api_instance.vertical_read_all_resource()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ResourcesApi->vertical_read_all_resource: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[InlineResponse200]**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **vertical_read_one_resource**
> object vertical_read_one_resource(global_id)

Read one inter-site Resource GET

Read one inter-site resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ResourcesApi()
global_id = 'global_id_example' # str | 

try:
    # Read one inter-site Resource GET
    api_response = api_instance.vertical_read_one_resource(global_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ResourcesApi->vertical_read_one_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **global_id** | **str**|  | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **vertical_update_resource**
> object vertical_update_resource(global_id, resource=resource)

Update an already deployed resource

Update an already deployed resource

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ResourcesApi()
global_id = 'global_id_example' # str | Global ID of the resource to update
resource = swagger_client.Resource1() # Resource1 |  (optional)

try:
    # Update an already deployed resource
    api_response = api_instance.vertical_update_resource(global_id, resource=resource)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ResourcesApi->vertical_update_resource: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **global_id** | **str**| Global ID of the resource to update | 
 **resource** | [**Resource1**](Resource1.md)|  | [optional] 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

