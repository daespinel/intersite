# Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | Type of inter-site resource | [optional] 
**name** | **str** | Name of the inter-site resource | [optional] 
**subresources** | **list[str]** | SubResourcess belonging to the user | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


