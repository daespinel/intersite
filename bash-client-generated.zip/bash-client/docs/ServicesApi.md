# ServicesApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**verticalCreateService**](ServicesApi.md#verticalCreateService) | **POST** /intersite-vertical | Creates an inter-site Service POST
[**verticalDeleteService**](ServicesApi.md#verticalDeleteService) | **DELETE** /intersite-vertical/{global_id} | Deletes an inter-site Service DELETE
[**verticalReadAllService**](ServicesApi.md#verticalReadAllService) | **GET** /intersite-vertical | the inter-site Service mapping structure GET
[**verticalReadOneService**](ServicesApi.md#verticalReadOneService) | **GET** /intersite-vertical/{global_id} | Read one inter-site Service GET
[**verticalUpdateService**](ServicesApi.md#verticalUpdateService) | **PUT** /intersite-vertical/{global_id} | Update an already deployed service


## **verticalCreateService**

Creates an inter-site Service POST

Create an inter-site service

### Example
```bash
 verticalCreateService
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service** | [**Service**](Service.md) | data for inter-service creation |

### Return type

**map**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **verticalDeleteService**

Deletes an inter-site Service DELETE

Deletes an inter-site service

### Example
```bash
 verticalDeleteService global_id=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **globalId** | **string** | Id of the service to delete |

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **verticalReadAllService**

the inter-site Service mapping structure GET

Read the list of inter-site services

### Example
```bash
 verticalReadAllService
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**array[Inline_response_200]**](Inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **verticalReadOneService**

Read one inter-site Service GET

Read one inter-site service

### Example
```bash
 verticalReadOneService global_id=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **globalId** | **string** |  |

### Return type

**map**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **verticalUpdateService**

Update an already deployed service

Update an already deployed service

### Example
```bash
 verticalUpdateService global_id=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **globalId** | **string** | Global ID of the service to update |
 **service** | [**Service_1**](Service_1.md) |  | [optional]

### Return type

**map**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

