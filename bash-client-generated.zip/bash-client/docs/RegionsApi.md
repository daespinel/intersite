# RegionsApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**readRegionName**](RegionsApi.md#readRegionName) | **GET** /region | Get the local region name


## **readRegionName**

Get the local region name

Read the local region name

### Example
```bash
 readRegionName
```

### Parameters
This endpoint does not need any parameter.

### Return type

**map**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

