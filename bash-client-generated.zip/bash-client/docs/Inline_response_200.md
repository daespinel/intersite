# inline_response_200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_id** | **string** |  | [optional] [default to null]
**service_type** | **string** |  | [optional] [default to null]
**service_name** | **string** |  | [optional] [default to null]
**service_params** | **string** |  | [optional] [default to null]
**service_resources** | [**array[Intersitevertical_service_resources]**](Intersitevertical_service_resources.md) |  | [optional] [default to null]
**service_interconnections** | [**array[Intersitevertical_service_interconnections]**](Intersitevertical_service_interconnections.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


