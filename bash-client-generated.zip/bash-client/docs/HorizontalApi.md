# HorizontalApi

All URIs are relative to */api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**horizontalCreateService**](HorizontalApi.md#horizontalCreateService) | **POST** /intersite-horizontal | Horizontal request to create an inter-site Service POST
[**horizontalDeleteService**](HorizontalApi.md#horizontalDeleteService) | **DELETE** /intersite-horizontal/{global_id} | Deletes an inter-site Service DELETE
[**horizontalReadParameters**](HorizontalApi.md#horizontalReadParameters) | **GET** /intersite-horizontal/{global_id} | Read the local cidr of an inter-site Service
[**horizontalUpdateService**](HorizontalApi.md#horizontalUpdateService) | **PUT** /intersite-horizontal/{global_id} | Update an already deployed service


## **horizontalCreateService**

Horizontal request to create an inter-site Service POST

Horizontal request to create an inter-site Service

### Example
```bash
 horizontalCreateService
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **service** | [**Service_2**](Service_2.md) | data for inter-site creation |

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **horizontalDeleteService**

Deletes an inter-site Service DELETE

Deletes an inter-site service

### Example
```bash
 horizontalDeleteService global_id=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **globalId** | **string** | Id of the service to delete |

### Return type

(empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **horizontalReadParameters**

Read the local cidr of an inter-site Service

Read one inter-site service

### Example
```bash
 horizontalReadParameters global_id=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **globalId** | **string** |  |

### Return type

**map**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **horizontalUpdateService**

Update an already deployed service

Update an already deployed service

### Example
```bash
 horizontalUpdateService global_id=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **globalId** | **string** | Global ID of the service to update |
 **service** | [**Service_3**](Service_3.md) |  | [optional]

### Return type

**map**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

