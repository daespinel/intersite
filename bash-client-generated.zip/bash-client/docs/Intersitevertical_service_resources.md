# intersitevertical_service_resources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_id** | **integer** |  | [optional] [default to null]
**resource_region** | **string** |  | [optional] [default to null]
**resource_uuid** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


